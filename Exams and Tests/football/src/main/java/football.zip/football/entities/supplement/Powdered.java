package football.entities.supplement;

public class Powdered extends BaseSupplement{

    public Powdered() {
        super(120, 15.0);
    }

}
