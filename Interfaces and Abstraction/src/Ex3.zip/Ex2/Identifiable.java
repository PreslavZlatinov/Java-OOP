package Ex2;

public interface Identifiable {
    String getId();
}
