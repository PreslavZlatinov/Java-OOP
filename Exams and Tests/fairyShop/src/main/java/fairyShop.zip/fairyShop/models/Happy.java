package fairyShop.models;

import java.util.Collection;

public class Happy extends BaseHelper{

    public Happy(String name) {
        super(name, 100);
    }

}
