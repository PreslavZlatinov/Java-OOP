package restaurant.entities.healthyFoods;

import restaurant.entities.healthyFoods.Food;

public class Salad extends Food {

    public Salad(String name, double price) {
        super(name, 150, price);
    }
}
