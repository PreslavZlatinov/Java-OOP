package zoo.entities.foods;

public class Vegetable extends BaseFood{

    public Vegetable() {
        super(50, 5.0);
    }

}
