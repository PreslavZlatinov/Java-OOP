package catHouse.entities.houses;

public class ShortHouse extends BaseHouse{

    public ShortHouse(String name) {
        super(name, 15);
    }
}
