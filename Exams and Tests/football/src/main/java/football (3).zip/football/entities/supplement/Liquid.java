package football.entities.supplement;

public class Liquid extends BaseSupplement{

    public Liquid() {
        super(90, 25.0);
    }

}
