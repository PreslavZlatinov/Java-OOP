package catHouse.entities.toys;

public class Mouse extends BaseToy{

    protected Mouse() {
        super(5, 15.0);
    }

}
