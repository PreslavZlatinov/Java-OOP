package Card_Suit;

public enum Suit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;

}
