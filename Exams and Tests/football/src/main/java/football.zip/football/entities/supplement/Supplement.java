package football.entities.supplement;

public interface Supplement {
    int getEnergy();

    double getPrice();
}
