package Ex2;

public interface Birthable {
    String getBirthDate();
}
