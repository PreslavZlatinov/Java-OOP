package Traffic_Lights;

public enum Lights {
    RED,
    GREEN,
    YELLOW;
}
