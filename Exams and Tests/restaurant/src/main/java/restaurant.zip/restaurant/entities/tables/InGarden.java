package restaurant.entities.tables;

public class InGarden extends BaseTable{
    public InGarden(int number, int size) {
        super(number, size, 4.50);
    }
}
